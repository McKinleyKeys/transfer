//
//  WePalsShared.h
//  WePalsShared
//
//  Created by McKinley Keys on 13/5/20.
//  Copyright © 2020 McKinley Keys. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for WePalsShared.
FOUNDATION_EXPORT double WePalsSharedVersionNumber;

//! Project version string for WePalsShared.
FOUNDATION_EXPORT const unsigned char WePalsSharedVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WePalsShared/PublicHeader.h>


