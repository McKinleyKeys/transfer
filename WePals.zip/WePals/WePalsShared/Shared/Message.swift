//
//  Message.swift
//  WePalsShared
//
//  Created by McKinley Keys on 13/5/20.
//  Copyright © 2020 McKinley Keys. All rights reserved.
//

import Foundation

public class Message: Codable {
	
	public let text: String
	
	public init(_ text: String) {
		self.text = text
	}
	
	public func serialize() -> String {
		do {
			let encoder = JSONEncoder()
			let data = try encoder.encode(self)
			guard let string = String(data: data, encoding: .utf8) else {
				Swift.fatalError("Failed to serialize message")
			}
			return string
		}
		catch {
			Swift.fatalError("Failed to serialize message")
		}
	}
	
	public static func deserialize(_ string: String) -> Message {
		do {
			let decoder = JSONDecoder()
			guard let data = string.data(using: .utf8) else {
				fatalError("Failed to get data for message!")
			}
			let message: Message = try decoder.decode(Message.self, from: data)
			return message
		}
		catch {
			fatalError("Failed to deserialize message")
		}
	}
}

