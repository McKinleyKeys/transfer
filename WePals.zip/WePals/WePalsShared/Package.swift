// swift-tools-version:4.2

import PackageDescription

let package = Package(
	name: "WePalsShared",
	products: [
		.library(name: "WePalsShared", targets: ["WePalsShared"])
	],
	dependencies: [],
	targets: [
		.target(name: "WePalsShared", dependencies: [], path: "Shared/")
	]
)
