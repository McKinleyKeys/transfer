//
//  View.swift
//  WePals
//
//  Created by McKinley Keys on 13/5/20.
//  Copyright © 2020 McKinley Keys. All rights reserved.
//

import UIKit
import WePalsShared

class View: UIView {
	
	static var mainView: View!
	
	@IBOutlet weak var connectedLabel: UILabel!
	@IBOutlet weak var messageTextField: UITextField!
	@IBOutlet weak var responseTextField: UITextField!
	
	@IBAction func connectButtonPressed(_ sender: Any) {
		Messenger.shared.connect()
	}
	@IBAction func sendButtonPressed(_ sender: Any) {
		Messenger.shared.sendMessage(Message(messageTextField.text ?? ""))
	}
}
