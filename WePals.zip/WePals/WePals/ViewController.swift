//
//  ViewController.swift
//  WePals
//
//  Created by McKinley Keys on 13/5/20.
//  Copyright © 2020 McKinley Keys. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

	override func viewDidLoad() {
		super.viewDidLoad()
		// Do any additional setup after loading the view.
		
		View.mainView = self.view as? View
	}


}

