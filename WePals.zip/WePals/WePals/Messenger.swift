//
//  Messenger.swift
//  WePals
//
//  Created by McKinley Keys on 13/5/20.
//  Copyright © 2020 McKinley Keys. All rights reserved.
//

import Foundation
import Starscream
import WePalsShared

class Messenger: WebSocketDelegate {
	
	static let shared = Messenger()
	
	private var socket: WebSocket
	var isConnected = false
	
	private init() {
		var request = URLRequest(url: URL(string: "http://localhost:1337")!)
		request.timeoutInterval = 5
		socket = WebSocket(request: request)
		socket.delegate = self
	}
	
	func connect() {
		socket.connect()
	}
	func disconnect() {
		socket.disconnect()
	}
	
	func sendMessage(_ message: Message) {
		
		let encoder = JSONEncoder()
		do {
			let data = try encoder.encode(message)
			socket.write(data: data)
		}
		catch {
			fatalError("Failed to serialize message!")
		}
	}
	
	// MARK: - WebSocketDelegate
	
	func didReceive(event: WebSocketEvent, client: WebSocket) {
		switch event {
        case .connected:
            isConnected = true
			print("Connected to server")
			let label = View.mainView.connectedLabel!
			label.text = "Connected"
			label.backgroundColor = UIColor.green
        case .disconnected(let reason, let code):
            isConnected = false
            print("Disconnected from server with code \(code). Reason: \(reason)")
			let label = View.mainView.connectedLabel!
			label.text = "Not connected"
			label.backgroundColor = UIColor.red
        case .text(let string):
            print("Received text: \(string)")
			let message = Message.deserialize(string)
			View.mainView.responseTextField.text = message.text
        case .binary(let data):
            print("Received data: \(data.count)")
        case .ping(_):
            break
        case .pong(_):
            break
        case .viabilityChanged(_):
            break
        case .reconnectSuggested(_):
			print("Reconnect is suggested")
            break
        case .cancelled:
			print("Connection to server was cancelled")
            isConnected = false
        case .error(let error):
            isConnected = false
			guard let error = error else {
				return print("Connection to server produced an error")
			}
			print("Connection to server produced error \(error)")
        }
	}
	
}
