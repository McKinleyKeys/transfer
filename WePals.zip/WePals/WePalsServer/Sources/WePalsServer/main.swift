//
//  main.swift
//  WePalsServer
//
//  Created by McKinley Keys on 13/5/20.
//  Copyright © 2020 McKinley Keys. All rights reserved.
//

import PerfectHTTP
import PerfectHTTPServer
import PerfectWebSockets
import PerfectLib

func makeRoutes() -> Routes {
	
	var routes = Routes()
	routes.add(method: .get, uri: "/", handler: { (request, response) in
		
		let webSocketHandler = WebSocketHandler(handlerProducer: {(request: HTTPRequest, protocols: [String]?) -> WebSocketSessionHandler? in
			
			return MessageHandler()
		})
		webSocketHandler.handleRequest(request: request, response: response)
	})
	return routes
}

try HTTPServer.launch(name: "localhost", port: 1337, routes: makeRoutes())

