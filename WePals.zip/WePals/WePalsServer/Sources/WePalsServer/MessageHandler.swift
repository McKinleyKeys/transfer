//
//  MessageHandler.swift
//  WePalsServer
//
//  Created by McKinley Keys on 13/5/20.
//

import Foundation
import PerfectWebSockets
import PerfectHTTP
import WePalsShared

class MessageHandler: WebSocketSessionHandler {
	
	let socketProtocol: String? = nil
	
	func handleSession(request: HTTPRequest, socket: WebSocket) {
		
		socket.readStringMessage(continuation: {(string, opcodeType, complete) in
			
			guard let string = string else {
				return print("Nil message received!")
			}
			
			let message = Message.deserialize(string)
			
			print("Received message:", message.text)
			
			let response = Message("Hello, client!")
			socket.sendStringMessage(string: response.serialize(), final: true, completion: {
				print("Sent response to client")
			})
			
			self.handleSession(request: request, socket: socket)
		})
	}
}

