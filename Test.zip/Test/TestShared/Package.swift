// swift-tools-version:4.2

import PackageDescription

let package = Package(
	name: "TestShared",
	products: [
		.library(name: "TestShared", targets: ["TestShared"])
	],
	dependencies: [],
	targets: [
		.target(name: "TestShared", dependencies: [], path: "Sources")
	]
)
