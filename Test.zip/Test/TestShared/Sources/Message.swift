//
//  Message.swift
//  TestShared
//
//  Created by McKinley Keys on 13/5/20.
//  Copyright © 2020 McKinley Keys. All rights reserved.
//

import Foundation

public class Message {
	
	public func sayHello() {
		print("hello")
	}
}
